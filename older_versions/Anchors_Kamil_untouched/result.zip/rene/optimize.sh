#!/bin/bash

python determine_anchor_strength.py  align.txt 0.5 anchors_template.txt vtml.mat
